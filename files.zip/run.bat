@echo off
chcp 65001 >nul
rem Запуск калькулятора на Windows 10.
rem Если установлен Python — поднимаем локальный сервер (работают ссылки ../),
rem иначе просто открываем файл в браузере по умолчанию.
setlocal
set "PORT=%~1"
if "%PORT%"=="" set "PORT=8080"
set "DIR=%~dp0"
set "DIR=%DIR:~0,-1%"
for %%I in ("%DIR%") do set "NAME=%%~nxI"
for %%I in ("%DIR%\..") do set "ROOT=%%~fI"

set "PY="
py -3 --version >nul 2>&1 && set "PY=py -3"
rem python --version отсекает заглушку Microsoft Store, которая ничего не запускает
if not defined PY python --version >nul 2>&1 && set "PY=python"

if not defined PY (
  echo Python не найден - открываю index.html напрямую.
  start "" "%DIR%\index.html"
  exit /b 0
)

set "URL=http://127.0.0.1:%PORT%/%NAME%/"
echo Калькулятор: %URL%
echo Остановить: Ctrl+C или закрыть это окно
start "" /b powershell -NoProfile -Command "Start-Sleep -Seconds 1; Start-Process '%URL%'"
%PY% -m http.server %PORT% --bind 127.0.0.1 --directory "%ROOT%"
