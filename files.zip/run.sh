#!/usr/bin/env bash
# Запуск калькулятора на Ubuntu 24.04: локальный веб-сервер + открытие браузера.
# Раздаётся родительская папка, чтобы работали ссылки ../index.html и ../favicon.svg.
set -euo pipefail

PORT="${1:-8080}"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$DIR")"
URL="http://127.0.0.1:${PORT}/$(basename "$DIR")/"

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 не найден. Установите: sudo apt install -y python3" >&2
  exit 1
fi

if ss -ltn 2>/dev/null | grep -q ":${PORT} "; then
  echo "Порт ${PORT} занят. Запустите с другим портом: ./run.sh 8081" >&2
  exit 1
fi

echo "Калькулятор: ${URL}"
echo "Остановить: Ctrl+C"
( sleep 1; xdg-open "$URL" >/dev/null 2>&1 || true ) &
exec python3 -m http.server "$PORT" --bind 127.0.0.1 --directory "$ROOT"
